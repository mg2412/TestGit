import yaml
from dataclasses import dataclass
import ibm_boto3
from ibm_botocore.client import Config, ClientError
from pprint import pprint

@dataclass
class Readconfig:
    '''
    Class to read config files
    '''
    file_name : str

    def read_config (self):
        '''
        Method to read config file
        '''
        with open(self.file_name) as cf:
            config = yaml.load(cf,Loader=yaml.FullLoader)
        return config

@dataclass
class WriteCos:
    config_file : str
    

    config :  dict
    

    # def __post_init__self(self):
    #     self.config= Readconfig(self.config_file).read_config()
    
    
    def create_cos_conn_object(self):
        api_key = self.config['Cosconfig'][1]['COS_API_KEY_ID']
        crn_inst = self.config['Cosconfig'][2]['COS_INSTANCE_CRN']
        cos_end_point = self.config['Cosconfig'][0]['COS_END_POINT']
        cos = ibm_boto3.client('s3',
            ibm_api_key_id=api_key,
            ibm_service_instance_id=crn_inst,
            verify=False,
            config=Config(signature_version="oauth"),
            endpoint_url=cos_end_point)
        return cos

    def upload_to_cos(self,bucket_name,item_name,file_path):
        print(f'Starting to upload file {item_name} to {file_path} on bucket : {bucket_name} ....')

        #set chunk size
        part_size = 1024 * 1024 * 5

        file_threshold =  1024 * 1024 * 5

        cos_conn = self.create_cos_conn_object()

        transfer_config = ibm_boto3.s3.transfer.TransferConfig(
            multipart_threshold = file_threshold,
            multipart_chunksize = part_size
        )

        #Create transfer manager
        transfer_mgr = ibm_boto3.s3.transfer.TransferManager(cos_conn, config=transfer_config)

        try:
            #initiate file upload
            future = transfer_mgr.upload(file_path,bucket_name,item_name)
            future.result()

            print(f'File {item_name} uploaded ......')
        except Exception as e:
            print(f'Unable to upload file, error {e} encountered')
        finally:
            transfer_mgr.shutdown()
""" 
if __name__=='__main__':
    #Read config
    file_path = 'resources/config.yaml'
    config = Readconfig(file_path).read_config()
    bucket_name = config['Cosconfig'][3]['COS_BUCKET']
    #item_name = 'test/claim.xlsx'
    #file_path = '/claim.xlsx'
    item_name = config['Filedetails'][0]['FILE_PATH']
    file_path = config['Filedetails'][1]['ITEM_NAME']
    WriteCos(file_path,config).upload_to_cos(bucket_name,item_name,file_path)

    #pprint(config['Cosconfig'][1]['COS_API_KEY_ID'])

   try:
        WriteCos(file_path,config).create_cos_conn_object()
        print('Connected !!')
    except Exception as e:
        print(f'Exception {e} encountered') 
    

  """   


  
  




