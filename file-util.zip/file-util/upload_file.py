import argparse
from file_copy import filecp

import os
import sys

parser = argparse.ArgumentParser(prog='filecp', description='Utility to upload files to IBM COS')
parser.add_argument('-c','--config',type=str,help='config yaml location')

args=parser.parse_args()

file_path = args.config

conf = filecp.Readconfig(file_path).read_config()
bucket_name = conf['Cosconfig'][3]['COS_BUCKET']

item_name = conf['Filedetails'][1]['ITEM_NAME']
file_path = conf['Filedetails'][0]['FILE_PATH']
filecp.WriteCos(file_path,conf).upload_to_cos(bucket_name,item_name,file_path)

